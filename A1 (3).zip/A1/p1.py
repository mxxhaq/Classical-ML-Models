import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold

# Load dataset
def load_data(folder="knn-dataset"):
    train_inputs = pd.read_csv(os.path.join(folder, "train_inputs.csv"), header=None).values
    train_targets = pd.read_csv(os.path.join(folder, "train_labels.csv"), header=None).values.ravel()
    test_inputs = pd.read_csv(os.path.join(folder, "test_inputs.csv"), header=None).values
    test_targets = pd.read_csv(os.path.join(folder, "test_labels.csv"), header=None).values.ravel()
    return train_inputs, train_targets, test_inputs, test_targets

# Compute Euclidean distance
def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2) ** 2, axis=1))

# KNN classifier implementation
class KNNClassifier:
    def __init__(self, k=3):
        self.k = k
    
    def fit(self, X, y):
        self.X_train = X
        self.y_train = y
    
    def predict(self, X):
        predictions = []
        for x in X:
            distances = euclidean_distance(self.X_train, x)
            k_indices = np.argsort(distances)[:self.k]
            k_nearest_labels = self.y_train[k_indices]
            most_common = np.bincount(k_nearest_labels.astype(int)).argmax()
            predictions.append(most_common)
        return np.array(predictions)

# 10-Fold Cross Validation
def cross_validate(X, y, k_values, folds=10):
    kf = KFold(n_splits=folds, shuffle=True, random_state=42)
    avg_accuracies = []
    
    for k in k_values:
        knn = KNNClassifier(k)
        fold_accuracies = []
        for train_idx, val_idx in kf.split(X):
            X_train, X_val = X[train_idx], X[val_idx]
            y_train, y_val = y[train_idx], y[val_idx]
            
            knn.fit(X_train, y_train)
            predictions = knn.predict(X_val)
            accuracy = np.mean(predictions == y_val)
            fold_accuracies.append(accuracy)
        
        avg_accuracies.append(np.mean(fold_accuracies))
    
    return avg_accuracies

# Load data
train_inputs, train_targets, test_inputs, test_targets = load_data()

# Cross-validation for different k values
k_values = range(1, 31)
avg_accuracies = cross_validate(train_inputs, train_targets, k_values)

# Find the best k
best_k = k_values[np.argmax(avg_accuracies)]
best_accuracy = max(avg_accuracies)

# Train final model and test
knn_best = KNNClassifier(best_k)
knn_best.fit(train_inputs, train_targets)
test_predictions = knn_best.predict(test_inputs)
test_accuracy = np.mean(test_predictions == test_targets)

# Plot results
plt.figure(figsize=(10, 6))
plt.plot(k_values, avg_accuracies, marker='o', linestyle='-')
plt.xlabel('Number of Neighbors (k)')
plt.ylabel('Cross-Validation Accuracy')
plt.title('KNN Cross-Validation Accuracy vs. k')
plt.grid()
plt.show()

# Print results
print(f"Best k: {best_k}, Cross-validation Accuracy: {best_accuracy:.4f}")
print(f"Test Accuracy with k={best_k}: {test_accuracy:.4f}")
